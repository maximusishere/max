from django.urls import path
from blog.views import (
    CategoryPost,
    EditProfile,
    PostCreate,
    ProfileDetail,
    PostList,
    PostDelete,
    PostDetail,
    PostEdit,
    CommentCreate,
    CommentDelete,
    CommentEdit,
)

app_name = 'blog'

urlpatterns = [
    path('', PostList.as_view(), name='index'),
    path('posts/create/', PostCreate.as_view(), name='create_post'),
    path('posts/<int:post_id>/', PostDetail.as_view(), name='post_detail'),
    path('posts/<int:post_id>/edit/', PostEdit.as_view(), name='edit_post'),
    path('posts/<int:post_id>/delete/',
         PostDelete.as_view(),
         name='delete_post'
         ),
    path('posts/<int:post_id>/comment/',
         CommentCreate.as_view(),
         name='add_comment'),
    path('posts/<int:post_id>/edit_comment/<int:comment_id>/',
         CommentEdit.as_view(),
         name='edit_comment'),
    path('posts/<int:post_id>/delete_comment/<int:comment_id>/',
         CommentDelete.as_view(),
         name='delete_comment'),
    path('category/<slug:category_slug>/',
         CategoryPost.as_view(),
         name='category_posts'),
    path('profile/edit/', EditProfile.as_view(), name='edit_profile'),
    path('profile/<slug:username>/', ProfileDetail.as_view(), name='profile'),
]
