from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.mixins import UserPassesTestMixin, LoginRequiredMixin
from django.contrib.auth import get_user_model
from django.db.models import Count, Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect
from django.utils import timezone
from django.urls import reverse_lazy, reverse
from django.views.generic import (
    CreateView, DetailView, ListView, UpdateView, DeleteView)
from blog.models import Post, Category, Comment
from .forms import PostForm, CommentForm, ProfileForm


User = get_user_model()


class OnlyAuthorMixin(UserPassesTestMixin):

    def test_func(self):
        object = self.get_object()
        return object.author == self.request.user


class CommentFormClassMixin:
    form_class = CommentForm


class CommentModelMixin:
    model = Comment


class PostModelMixin:
    model = Post


class ProfileModelMixin:
    model = User


class PkKwargMixin:
    pk_url_kwarg = 'post_id'


class ProfileDetail(ProfileModelMixin, DetailView):
    template_name = 'blog/profile.html'
    context_object_name = 'post'

    def get_queryset(self):
        return Post.published.select_related('author')

    def get_object(self):
        username = self.kwargs['username']
        user = get_object_or_404(User, username=username)
        return user

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile = self.get_object()
        posts = profile.posts.select_related('author').all().annotate(
            comment_count=Count('comments'))
        sorted_posts = posts.order_by('-pub_date')

        paginator = Paginator(sorted_posts, 10)
        page_number = self.request.GET.get('page')

        try:
            page_obj = paginator.page(page_number)
        except PageNotAnInteger:
            page_obj = paginator.page(1)
        except EmptyPage:
            page_obj = paginator.page(paginator.num_pages)

        context['page_obj'] = page_obj
        context['profile'] = profile
        return context


class EditProfile(ProfileModelMixin, LoginRequiredMixin, UpdateView):
    template_name = 'blog/user.html'
    form_class = ProfileForm
    User = get_user_model()

    def get_object(self):
        return self.request.user

    def get_success_url(self):
        return reverse(
            'blog:profile', kwargs={'username': self.request.user.username})


class PostCreate(PostModelMixin, LoginRequiredMixin, CreateView):
    template_name = 'blog/create.html'
    form_class = PostForm

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def post_select_related(self):
        return Post.objects.select_related(
            'author', 'location', 'category'
        ).filter(
            pub_date__lte=timezone.now(),
            is_published=True,
            category__is_published=True)

    def get_success_url(self):
        # title = self.object.title
        return reverse(
            'blog:profile', kwargs={'username': self.request.user.username})


class CommentCreate(
    LoginRequiredMixin,
    CommentFormClassMixin,
    CommentModelMixin,
    PkKwargMixin,
    CreateView
):
    template_name = 'blog/comment.html'

    def form_valid(self, form):
        post = get_object_or_404(Post, id=self.kwargs['post_id'])
        form.instance.post = post
        form.instance.author = self.request.user
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        post = get_object_or_404(Post, id=self.kwargs['post_id'])
        context['comments'] = post.comments.all().order_by('created_at')
        context['post'] = post
        # context['text'] = self.object.comments.select_related('author')
        return context

    def get_success_url(self):
        return reverse(
            'blog:post_detail', kwargs={'post_id': self.kwargs['post_id']})


class PostList(PostModelMixin, ListView):
    template_name = 'blog/index.html'
    paginate_by = 10

    def get_queryset(self):
        queryset = super().get_queryset().filter(
            pub_date__lte=timezone.now(),
            category__is_published=True,
            is_published=True
        ).order_by('-pub_date')
        queryset = queryset.annotate(comment_count=Count('comments'))
        return queryset


class PostDetail(DetailView):
    model = Post
    pk_url_kwarg = 'post_id'
    template_name = 'blog/detail.html'
    form_class = CommentForm

    def get_queryset(self):

        queryset = super().get_queryset()
        if self.request.user.is_authenticated:
            return queryset.filter(
                Q(is_published=True) | Q(author=self.request.user)
            )
        else:
            return queryset.filter(is_published=True)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = self.form_class()

        if self.request.user.is_authenticated:
            context['comments'] = self.object.comments.select_related('author')
        else:
            context['comments'] = []

        if not (self.object.is_published
                ) and self.object.author != self.request.user:
            raise Http404("Пост не найден")

        return context


class CategoryPost(PostModelMixin, ListView):
    template_name = 'blog/category.html'
    context_object_name = 'categoty'
    paginate_by = 10

    def get_queryset(self):
        category_slug = self.kwargs.get('category_slug')
        self.category = get_object_or_404(
            Category, slug=category_slug, is_published=True
        )
        return super().get_queryset(
        ).filter(category=self.category, pub_date__lte=timezone.now(
        ), is_published=True).order_by('-pub_date')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['category'] = self.category
        return context


class PostDelete(PostModelMixin, OnlyAuthorMixin, PkKwargMixin, DeleteView):
    form_class = PostForm
    template_name = 'blog/create.html'
    success_url = reverse_lazy('blog:index')


class PostEdit(PostModelMixin, PkKwargMixin, OnlyAuthorMixin, UpdateView):
    form_class = PostForm
    template_name = 'blog/create.html'

    def dispatch(self, request, *args, **kwargs):
        if self.get_object().author != request.user:
            return redirect(
                'blog:post_detail',
                post_id=self.kwargs['post_id']
            )
        return super().dispatch(request, *args, **kwargs)

    def get_success_url(self):
        return reverse(
            'blog:post_detail',
            kwargs={'post_id': self.object.pk}
        )


class CommentEdit(
    CommentModelMixin,
    CommentFormClassMixin,
    PkKwargMixin,
    OnlyAuthorMixin,
    UpdateView
):
    template_name = 'blog/comment.html'

    def dispatch(self, request, *args, **kwargs):

        if self.get_object().author != request.user:
            return redirect(
                'blog:post_detail',
                post_id=self.kwargs['post_id']
            )
        return super().dispatch(request, *args, **kwargs)

    def get_success_url(self):
        return reverse(
            'blog:post_detail',
            kwargs={
                'post_id': self.object.post.id
            }
        )


class CommentDelete(
    CommentModelMixin,
    CommentFormClassMixin,
    PkKwargMixin,
    DeleteView
):
    template_name = 'blog/comment.html'

    def dispatch(self, request, *args, **kwargs):
        if self.get_object().author != request.user:
            return redirect(
                'blog:post_detail',
                post_id=self.kwargs['post_id']
            )
        return super().dispatch(request, *args, **kwargs)

    def get_success_url(self):
        return reverse(
            'blog:post_detail', kwargs={'post_id': self.object.post.id})
